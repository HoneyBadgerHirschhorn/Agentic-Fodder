package guitarshop.service;

import guitarshop.exception.OutOfStockException;
import guitarshop.exception.ResourceNotFoundException;
import guitarshop.model.Guitar;
import guitarshop.repository.GuitarRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
public class GuitarService {

    private final GuitarRepository repository;

    public GuitarService(GuitarRepository repository) {
        this.repository = repository;
    }

    public List<Guitar> findAll() {
        return repository.findAll();
    }

    public List<Guitar> findByType(String type) {
        return repository.findByType(type.toUpperCase());
    }

    public Guitar findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Guitar not found with id: " + id));
    }

    @Transactional
    public Guitar purchase(Long id) {
        Guitar guitar = findById(id);
        if (guitar.getInventory() <= 0) {
            throw new OutOfStockException(
                "Sorry, the " + guitar.getBrand() + " " + guitar.getModelName() + " is currently out of stock."
            );
        }
        guitar.setInventory(guitar.getInventory() - 1);
        return repository.save(guitar);
    }
}
